import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth";
import { Toaster } from "@/components/ui/sonner";
import { AetherIntro } from "@/components/AetherIntro";
import { useEffect, useState } from "react";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { name: "theme-color", content: "#000000" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-status-bar-style", content: "black-translucent" },
      { name: "apple-mobile-web-app-title", content: "AETHER" },
      { title: "AETHER — Angebote für Handwerker" },
      { name: "description", content: "Erstelle in Sekunden professionelle Angebote. Per Sprache oder manuell. PDF-Export inklusive." },
      { name: "author", content: "AETHER" },
      { property: "og:title", content: "AETHER — Angebote für Handwerker" },
      { property: "og:description", content: "Erstelle in Sekunden professionelle Angebote. Per Sprache oder manuell. PDF-Export inklusive." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:title", content: "AETHER — Angebote für Handwerker" },
      { name: "twitter:description", content: "Erstelle in Sekunden professionelle Angebote. Per Sprache oder manuell. PDF-Export inklusive." },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/icon-512.png" },
      { rel: "icon", type: "image/png", href: "/icon-512.png" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const [showIntro, setShowIntro] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const seen = sessionStorage.getItem("aether_intro_seen");
      if (!seen) {
        setShowIntro(true);
        sessionStorage.setItem("aether_intro_seen", "1");
      }
    } catch {
      // sessionStorage may be unavailable — show intro once anyway
      setShowIntro(true);
    }
  }, []);

  return (
    <AuthProvider>
      {showIntro && <AetherIntro onDone={() => setShowIntro(false)} />}
      <Outlet />
      <Toaster />
    </AuthProvider>
  );
}
