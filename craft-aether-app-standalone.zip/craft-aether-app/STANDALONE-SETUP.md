# AETHER — Eigenständiger Betrieb (ohne Lovable)

Diese App wurde von Lovable entkoppelt. Zusammenfassung der Änderungen:

## Was wurde geändert

1. **`vite.config.ts`** – nutzt jetzt Standard-Vite-Plugins statt
   `@lovable.dev/vite-tanstack-config` (TanStack Start, React, Tailwind v4,
   TS-Path-Aliase — funktional identisch, nur ohne Lovable-Paket).
2. **`package.json`** – `@lovable.dev/vite-tanstack-config` als Dependency entfernt.
3. **`src/routes/api.transcribe.ts`** & **`src/routes/api.parse-positions.ts`**
   – riefen vorher `https://ai.gateway.lovable.dev/...` mit `LOVABLE_API_KEY` auf
   (Lovables AI-Proxy). Jetzt: direkter Aufruf der **OpenAI API**
   (`api.openai.com`) mit `OPENAI_API_KEY`.
   - Transkription: `gpt-4o-mini-transcribe`
   - Positionserkennung (Diktat → Angebotspositionen): `gpt-4o-mini` mit Function-Calling
4. **`src/routes/__root.tsx`** – Lovable-Branding (Twitter-Handle, Vorschaubild
   von Lovables CDN) entfernt.
5. **`src/hooks/use-audio-recorder.ts`** – Fehlermeldung nicht mehr
   Lovable-spezifisch formuliert.
6. **`.gitignore`** – `.env` ergänzt, damit Secrets nicht versehentlich
   committet werden.
7. **`supabase/config.toml`**, **`.env`**, **`.env.example`** – auf dein
   eigenes Supabase-Projekt (`oadiskuiqoqzneswjayh`) umgestellt.

Build (`npm run build`) und Dev-Server (`npm run dev`) wurden getestet und
laufen fehlerfrei ohne jede Lovable-Abhängigkeit.

---

## Was DU noch tun musst

### 1. Supabase-Zugangsdaten eintragen

In `.env` fehlen noch drei Werte aus deinem Supabase-Dashboard
(**Project Settings → API**, https://supabase.com/dashboard/project/oadiskuiqoqzneswjayh/settings/api):

```
SUPABASE_PUBLISHABLE_KEY="..."       # "anon" / "publishable" key
VITE_SUPABASE_PUBLISHABLE_KEY="..."  # derselbe Wert
SUPABASE_SERVICE_ROLE_KEY="..."      # "service_role" key — GEHEIM, nur Server!
```

Der `anon`-Key ist öffentlich (landet im Frontend-Bundle) — unbedenklich.
Der `service_role`-Key umgeht alle Row-Level-Security-Regeln und darf
**niemals** ins Frontend oder in ein öffentliches Repo gelangen.

### 2. Datenbank-Schema übertragen

Die App braucht die Tabellen `quotes`, `customers`, `sites`, `user_roles` etc.
Diese liegen als SQL-Migrationen unter `supabase/migrations/` (9 Dateien).
Zwei Wege, sie auf dein Projekt `oadiskuiqoqzneswjayh` zu übertragen:

**Variante A — Supabase CLI (empfohlen):**
```bash
npx supabase login
npx supabase link --project-ref oadiskuiqoqzneswjayh
npx supabase db push
```

**Variante B — manuell im SQL-Editor:**
Im Supabase-Dashboard → SQL Editor → jede Datei aus
`supabase/migrations/` in chronologischer Reihenfolge (Dateiname beginnt
mit Zeitstempel) einfügen und ausführen.

### 3. Auth-Einstellungen prüfen

Falls die App E-Mail/Passwort-Login nutzt: im Dashboard unter
**Authentication → Providers** prüfen, ob Email-Auth aktiv ist, und unter
**Authentication → URL Configuration** die Redirect-URLs deiner neuen
Domain/localhost eintragen.

### 4. OpenAI-Key besorgen (nur falls Spracheingabe genutzt wird)

Für die Diktier-/Spracherkennungs-Funktion (Sprachnotiz → Angebotspositionen)
wird ein eigener OpenAI-Key benötigt: https://platform.openai.com/api-keys
→ in `.env` als `OPENAI_API_KEY` eintragen. Ohne diesen Key läuft die App
normal, nur die Sprachfunktionen liefern einen Fehler.

### 5. Starten

```bash
npm install     # einmalig
npm run dev     # Entwicklung, http://localhost:5173
npm run build   # Produktions-Build nach dist/
npm run preview # Produktions-Build lokal testen
```

### 6. Deployment (optional)

Das Repo enthält bereits Konfigs für zwei Hoster:
- **Vercel**: `vercel.json` vorhanden → einfach Repo auf vercel.com importieren
  und die `.env`-Werte als Environment Variables eintragen.
- **Cloudflare**: `wrangler.jsonc` vorhanden → `npx wrangler deploy` (Secrets
  vorher per `npx wrangler secret put OPENAI_API_KEY` usw. setzen).

Beide sind optional — die App läuft genauso gut auf jedem eigenen Server/VPS
via `npm run build && npm run preview` bzw. mit einem Node-Prozessmanager.
