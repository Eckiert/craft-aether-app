import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import tsConfigPaths from "vite-tsconfig-paths";

// Eigenständige Vite-Konfiguration (ohne @lovable.dev/vite-tanstack-config).
// Ersetzt 1:1 das, was das Lovable-Paket vorher automatisch eingebunden hat:
// TanStack Start, React-Plugin, Tailwind v4, TS-Path-Aliase (@/*).
export default defineConfig({
  plugins: [
    tsConfigPaths({
      projects: ["./tsconfig.json"],
    }),
    tailwindcss(),
    tanstackStart({
      router: {
        codeSplittingOptions: {
          defaultBehavior: [],
        },
      },
    }),
    viteReact(),
  ],
  server: {
    port: 5173,
  },
});
